import math
import torch
from torch import nn
import numpy as np
import scipy.io as scio
import h5py
# from sklearn.model_selection import LeaveOneOut
import torch.nn.functional as F
import torch.optim as optim
import sklearn
from sklearn.model_selection import StratifiedKFold, KFold, GroupKFold
from sklearn.metrics import confusion_matrix
from torch.utils.data import DataLoader
import random
import seaborn as sns
import matplotlib.pyplot as plt
import csv
import os
os.environ['CUDA_LAUNCH_BLOCKING'] = "1"

torch.manual_seed(123)
np.random.seed(123)
random.seed(123)

class Data(object):
    def read_data(self, dataFile):

        data = scio.loadmat(dataFile)
        aal = data['AAL']
        A = aal[0]
        AAL = []
        for i in range(len(A)):
            pc = np.corrcoef(A[i].T)
            pc = np.nan_to_num(pc)
            AAL.append(pc)
        AAL = np.array(AAL)
        lab = np.squeeze(data['lab'])
        return AAL, lab

    def __init__(self, dataFile):
        super(Data, self).__init__()
        AALt, labt = self.read_data(dataFile)
        AALt = torch.tensor(AALt).float()
        self.AALt = AALt.permute(0, 2, 1)
        self.labt = torch.from_numpy(labt)
        self.n_samples = AALt.shape[0]

    def __getitem__(self, index):
        return self.AALt[index], self.labt[index]

    def __len__(self):
        return self.n_samples

class GSRData(object):
    def readd_data(self, dataFile):

        feature = h5py.File(dataFile)
        GSRAAL = feature['data_GSR5'][:]
        GSRAAL = np.transpose(GSRAAL,(2,0,1))

        return GSRAAL

    def __init__(self, dataFile):
        super(GSRData, self).__init__()
        AALt = self.readd_data(dataFile)
        AALt = torch.tensor(AALt).float()
        self.n_samples = AALt.shape[0]

    def __getitem__(self, index):
        return self.AALt[index]

    def __len__(self):
        return self.n_samples


class DotProductAttention(nn.Module):

    def __init__(self, dropout, **kwargs):
        super(DotProductAttention, self).__init__(**kwargs)
        self.dropout = nn.Dropout(dropout)

    def forward(self, queries, keys, values):
        d = queries.shape[-1]
        scores = torch.bmm(queries, keys.transpose(1, 2)) / math.sqrt(d)
        scores = nn.functional.softmax(scores, dim=-1)
        context = torch.matmul(scores, values)
        return context, scores


def transpose_qkv(X, num_heads):
    X = X.reshape(X.shape[0], X.shape[1], num_heads, -1)
    X = X.permute(0, 2, 1, 3)
    return X.reshape(-1, X.shape[2], X.shape[3])


def transpose_output(X, num_heads):
    X = X.reshape(-1, num_heads, X.shape[1], X.shape[2])
    X = X.permute(0, 2, 1, 3)
    return X.reshape(X.shape[0], X.shape[1], -1)


class MultiHeadAttention(nn.Module):
    def __init__(self, d_model, num_heads, dropout, bias=False, **kwargs):
        super(MultiHeadAttention, self).__init__(**kwargs)
        self.num_heads = num_heads
        self.attention = DotProductAttention(dropout)
        self.W_q = nn.Linear(d_model, d_model * num_heads)
        self.W_k = nn.Linear(d_model, d_model * num_heads)
        self.W_v = nn.Linear(d_model, d_model * num_heads)
        self.W_o = nn.Linear(d_model * num_heads, d_model)
        self.layer_norm = nn.LayerNorm(d_model)

    def forward(self, queries, keys, values):

        q = transpose_qkv(self.W_q(queries), self.num_heads)
        k = transpose_qkv(self.W_k(keys), self.num_heads)
        v = transpose_qkv(self.W_v(values), self.num_heads)

        output, scores = self.attention(q, k, v)
        output_concat = transpose_output(output, self.num_heads)
        output_concat = self.W_o(output_concat)
        return output_concat, scores


class AddNorm(nn.Module):

    def __init__(self, normalized_shape, dropout):
        super(AddNorm, self).__init__()
        self.dropout = nn.Dropout(dropout)
        self.ln = nn.LayerNorm(normalized_shape)

    def forward(self, X, Y):
        return self.ln(self.dropout(Y) + X)


class FeedForward(nn.Module):

    def __init__(self, input_size, hidden_size):
        super(FeedForward, self).__init__()
        self.linear1 = nn.Linear(input_size, hidden_size)
        self.relu = nn.ReLU()
        self.linear2 = nn.Linear(hidden_size, input_size)

    def forward(self, x):

        output = self.linear1(x)
        output = self.relu(output)
        output = self.linear2(output)
        return output

class EncoderLayer(nn.Module):
    def __init__(self, d_model, normalized_shape, input_size, hidden_size, num_heads, dropout):
        super(EncoderLayer, self).__init__()
        self.attention = MultiHeadAttention(d_model, num_heads, dropout)
        self.addnorm1 = AddNorm(normalized_shape, dropout)
        self.ffn = FeedForward(input_size, hidden_size)
        self.addnorm2 = AddNorm(normalized_shape, dropout)

    def forward(self, x):
        context, scores = self.attention(x, x, x)
        Y = self.addnorm1(x, context)
        encoded_output = self.addnorm2(Y, self.ffn(Y))
        return encoded_output, scores

class TransformerEncoder(nn.Module):

    def __init__(self, d_model, normalized_shape, input_size, hidden_size, num_heads, num_layers, dropout):
        super(TransformerEncoder, self).__init__()
        self.layers = nn.ModuleList([EncoderLayer(d_model, normalized_shape, input_size, hidden_size,
                                                   num_heads, dropout)
                                     for _ in range(num_layers)])

    def forward(self, x):
        for layer in self.layers:
            enc_outputs, enc_selfattn_score = layer(x)
        return enc_outputs, enc_selfattn_score


class MLPDecoder(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(MLPDecoder, self).__init__()
        self.fc1 = nn.Linear(13456, 64)
        self.fc2 = nn.Linear(64, 8)
        self.fc3 = nn.Linear(8, 2)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(p=0.5)

    def forward(self, x):
        x = x.view(x.size(0), -1)
        x = self.dropout(x)
        x = self.fc1(x)
        x = self.relu(x)
        x = self.dropout(x)
        x = self.fc2(x)
        x = self.relu(x)
        x = self.dropout(x)
        x = self.fc3(x)
        x = F.log_softmax(x, dim=1)
        return x


class TransformerClassifier(nn.Module):

    def __init__(self, encoder, decoder):
        super(TransformerClassifier, self).__init__()
        self.encoder = encoder
        self.decoder = decoder

    def forward(self, x):
        encoder_output, scores_all = self.encoder(x)
        logits = self.decoder(encoder_output)
        return logits, scores_all


def mmd_linear(f_of_X, f_of_Y):
    if f_of_X.size(1) != f_of_Y.size(1):
        f_of_X = f_of_X[:,:f_of_Y.size(1)]
    delta = f_of_X - f_of_Y
    loss = torch.mean(torch.mm(delta, torch.transpose(delta, 0, 1)))
    return loss

def get_device():
    return 'cuda' if torch.cuda.is_available() else 'cpu'


def accuracy(output, labels):
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()
    correct = correct.sum()
    return correct / len(labels), preds


def calculate_metric(gt, pred):
    pred[pred > 0.5] = 1
    pred[pred < 1] = 0
    confusion = confusion_matrix(gt, pred)
    TP = confusion[1, 1]
    TN = confusion[0, 0]
    FP = confusion[0, 1]
    FN = confusion[1, 0]
    acc = (TP + TN) / float(TP + TN + FP + FN)
    sen = TP / float(TP + FN)
    spe = TN / float(TN + FP)
    bac =(sen+spe)/2
    ppv = TP/float(TP+FP)
    npv = TN/float(TN+FN)
    pre =TP/float(TP+FP)
    rec =TP/float(TP+FN)
    f1_score = 2*pre*rec/(pre+rec)
    return acc, sen, spe, bac, ppv, npv, pre, rec, f1_score

def normalize_1(x):
    x_min = np.min(x)
    x_max = np.max(x)
    x_norm = ((x-x_min)/(x_max-x_min)) *2 - 1
    return x_norm

data = Data('C://Users/YoYo/data/NYU116.mat')
full_dataset = data.read_data('C://Users/YoYo/data/NYU116.mat')
AALt = full_dataset[0]
labt = full_dataset[1]
skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=3)
GSRpc = GSRData('C://Users/YoYo/data/NYU116_GSR2_-1.mat')
GSR_dataset = GSRpc.readd_data('C://Users/YoYo/data/NYU116_GSR2_-1.mat')

# 设置模型参数
d_model, hidden_size, input_size, normalized_shape = AALt.shape[2], AALt.shape[2], AALt.shape[2], AALt.shape[2]
num_hiddens = 256
num_layers =2
num_heads = 2
dropout = 0.5
learning_rate = 0.00001
num_epochs = 200
cc = 0.2
lamm = 0.8
device = get_device()

testpredfold = []
Labels = []
aucv = []
testaccfold = []
fold = 0
feature = []
testlab = []
# acctrue, sentrue, spetrue, bactrue, ppvtrue, npvtrue, pretrue, rectrue, f1_scoretrue, auctrue = [],[],[],[],[],[],[],[],[],[]
for train_index, test_index in skf.split(AALt, labt):
    fold += 1
    print('=========================fold=====================:', fold)
    train_data, train_label = AALt[train_index], labt[train_index]
    test_data, test_label = AALt[test_index], labt[test_index]
    gsrtrain_data = GSR_dataset[train_index]
    gsrtest_data = GSR_dataset[test_index]
    train_data = torch.tensor(train_data).to(torch.float32).to(device)
    train_label = torch.tensor(train_label).long().to(device)
    test_data = torch.tensor(test_data).to(torch.float32).to(device)
    test_label = torch.tensor(test_label).long().to(device)
    gsrtrain_data = torch.tensor(gsrtrain_data).to(torch.float32).to(device)
    gsrtest_data = torch.tensor(gsrtest_data).to(torch.float32).to(device)
    Labels.extend(test_label)

    encoder = TransformerEncoder(d_model, normalized_shape, input_size, hidden_size,
                                 num_heads, num_layers, dropout)
    decoder = MLPDecoder(input_size, num_hiddens)
    net = TransformerClassifier(encoder, decoder)
    net.to(device)

    optimizer = optim.Adam(net.parameters(), lr=learning_rate)
    criterion = nn.CrossEntropyLoss()
    gsrtrain_data = gsrtrain_data.reshape(gsrtrain_data.shape[0], -1)
    gsrtrain_data = gsrtrain_data.t()

    for epoch in range(num_epochs):
        ccc = cc
        lam = lamm
        test_loss = 0.0
        net.train()
        optimizer.zero_grad()
        output, scores_all = net(train_data)
        scores_all = scores_all.reshape(scores_all.shape[0], -1)
        scores_all = scores_all.t()
        bb = torch.norm(scores_all, p=2, dim=1).sum()
        mmmd = mmd_linear(scores_all, gsrtrain_data)
        train_l = criterion(F.softmax(output, dim=1), train_label.long()) + ccc*bb + lam*mmmd
        (train_acc, train_pred) = accuracy(output, train_label)
        train_l.backward()
        optimizer.step()
        print('Epoch: {:04d}'.format(epoch + 1),
              'train_loss: {:.4f}'.format(train_l),
              'train_acc: {:.4f}'.format(train_acc))

    net.eval()
    with torch.no_grad():
        output_test, scores_all_test = net(test_data)
        test_l = criterion(output_test, test_label.long())
        test_loss += test_l
        (test_acc, test_pred) = accuracy(output_test, test_label)

    print('-----------------------------------------------------'
            'test_loss: {:.4f}'.format(test_loss / len(test_label)),
            'test_acc: {:.4f}'.format(test_acc))

    testaccfold.append(test_acc)
    testaccfold_t = torch.tensor(testaccfold)

acc = average = sum(testaccfold_t) / len(testaccfold_t)
print(acc)
